AuthenticationAngularJS
=======================

This code is an example to create secured routes in AngularJS. To have more details, please go to [the tutorial](https://vickev.com/#!/article/authentication-in-single-page-applications-node-js-passportjs-angularjs).

To run this example: 
1. `npm install`
2. `node app.js`
